package pageobjects; // package declaration for pageobjects
// Importing the required packages
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class Purchasepageobj { 
	//WebDriver instance
 public WebDriver driver;
 // Locators for the elements on the purchase page
 By username = By.id("user-name");
 By password = By.id("password");
 By loginbutton = By.id("login-button");
 By item = By.xpath("//*[@id=\"item_4_img_link\"]/img");		
 By addtocart= By.id("add-to-cart-sauce-labs-backpack");
 By container= By.xpath("//*[@id=\"shopping_cart_container\"]/a");
 By checkout = By.id("checkout");
 By firstname = By.id("first-name");
 By lastname = By.id("last-name");
 By postalcode = By.id("postal-code");
 By continuebutton = By.id("continue");
 By finish = By.id("finish");
 By backtoproducts1 = By.id("back-to-products");
 // Constructor to initialize the driver instance
public Purchasepageobj(WebDriver driver) {
 this.driver = driver;    
                                         }
// Method to enter username
    public void enterUsername(String standard_user){
   	driver.findElement (username).sendKeys(standard_user); }	
    // method to enter password
	public void enterPassword(String Text)     {
	driver.findElement (password).sendKeys(Text);		   }
	// method to click the login button
	public void clickloginbutton()             {
	driver.findElement (loginbutton).click();			   }
	// method to click the item 
    public void clickItem()                    {
   	driver.findElement (item).click(); 	    	           }    	
    // method to click the add to cart button
	public void clickAddtocart()               {
	driver.findElement (addtocart).click();			       }	
	// method to click the container
	public void clickContainer()               {
	driver.findElement (container).click();		           }
	// method to click the checkout button
	public void clickCheckout()                {
	driver.findElement(checkout).click();		           }
	// setTextInfirstname method to set text in the first name field
	public void setTextInfirstname(String Text){
	driver.findElement (firstname).sendKeys(Text);  	   }
	// setTextInlastname method to set text last in the name field
	public void setTextInlastname(String Text) {
	driver.findElement (lastname).sendKeys(Text);	       }
	// setTextInpostalcode method to set text in the postal code field
	public void setTextInpostalcode(String Text){
	driver.findElement (postalcode).sendKeys(Text);		   }
	// clickContinuebutton method to click on the continue button
	public void clickContinuebutton()          {
	driver.findElement (continuebutton).click();		   }
	// clickfinish method to click on the finish button
	public void clickfinish()                  {
	driver.findElement (finish).click();		           }
	// clickBacktoproducts1 method to click on the back to products button
	public void clickBacktoproducts1()         {
	driver.findElement (backtoproducts1).click();	  }	   }


